<?php
header('Location: category');